package diagnostics

import java.util.ArrayList

syntax_err

fun func(){
    val list = ArrayList<String>()
    list.add("str")
    println("Hi")
}