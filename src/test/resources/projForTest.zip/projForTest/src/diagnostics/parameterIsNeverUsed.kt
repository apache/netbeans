package diagnostics

fun func(str : String) {}