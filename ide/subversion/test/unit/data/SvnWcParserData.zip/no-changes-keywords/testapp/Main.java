/*
 * Main.java
 *
 * Created on 12 April 2006, 20:36
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package testapp;

/**
 *
 * @version $Revision: 11 $
 * $Id: Main.java 330 2007-06-13 12:02:16Z tomas $
 * $Id: Main.java#$
 * $Id: Main.java#$
 * $Id:: Main.java#$
 * $Id: Main.java 330 2007-06-13 12:02:16Z tomas $ $Revision:$ $Author: tomas $ $Date: 2007-06-12 
 * 17:24:06 +0200 (Tue, 12 Jun 2007) $
 *
 * @author Ed Hillmann
 */
public class Main {

    /** Creates a new instance of Main */
    public Main() {
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
    }

}
