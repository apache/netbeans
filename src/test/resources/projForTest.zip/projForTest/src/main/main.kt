package main

/*

  @author Alexander.Baratynski
  Created on Jul 22, 2016
*/

fun main(args : Array<String>) {
    
}