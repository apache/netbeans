package diagnostics

fun func(str : String) {}

fun main(args : Array<String>) {
    println("Hello, world!")
}