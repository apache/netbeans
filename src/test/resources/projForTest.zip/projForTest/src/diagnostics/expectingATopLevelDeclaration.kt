package diagnostics

syntax_err

fun func(){
}